Dylan Gully [1]
===

This chapter title [with a link](http://zombo.com) is incorrect [2]
---

### This is a scene title [with a link in it](https://example.com) correct `TEXT-ONLY` [3]
- This is  [and it includes a clickable link](https://example.org) and a list item [and it includes a clickable link](https://example.org) [4]
2. must commit to creating "something" rather than waiting to have "the perfect referral program" [5]
3. The client who refers has to feel [6]
<!-- Yet another comment, just ignore it -->

### Use the "Ready, Fire, Aim!" approach [7]

6. This list starts with the number "6" [8]
7. It does not matter what the numbers are for the rest of the list [9]
7. So, for instance this element will have the number "8" when displayed in the player [10]
19228. And this element will have the number "9" [11]
1. So the player "fixes" the list numbers so that they are all consecutive numbers starting at the first number in the list [12]

Second chapter title [13]
---

### Une Masterclass pour qui ? [14]

- Cette formation s'adresse Ã  tous les niveaux de clarinette : [15]
	- Ã€ ceux qui ont 3 - 4 ans de clarinette [16]
	- Aux profs de conservatoire, aux intermittents et qui veulent s'initier aux musiques de l'est [17]
- Cette formation sera donc accessible Ã  la rentrÃ©e [18]
- En attendant, je vous propose une masterclass gratuite [19]
	- Aux profs de conservatoire, aux intermittents et qui veulent s'initier aux musiques de l'est [20]

Third chapter title [21]
---

### Masterclass - Ce que tu vas y apprendre [22]

- GrÃ¢ce Ã  cette Masterclass, tu vas notamment apprendre comment : [23]
	- Jouer les ornements des Balkans [24]
### Masterclass - Ce que tu vas y [25]
- Apprendre un morceau et surtout Ã  le jouer dans le style [26]
<del> [27]
</del> [28]

--- [29]

<!-- End of the project. Nothing is exported beyond this point -->
[1]: 00:00:00,000
[2]: 00:00:00,000
[3]: 00:00:00,000
[4]: 00:00:05,755
[5]: 00:00:06,410
[6]: 00:00:07,112
[7]: 00:00:15,380
[8]: 00:00:16,954
[9]: 00:00:19,917
[10]: 00:00:21,888
[11]: 00:00:23,189
[12]: 00:00:25,414
[13]: 00:00:28,168
[14]: 00:00:31,423
[15]: 00:00:34,643
[16]: 00:00:37,010
[17]: 00:00:40,117
[18]: 00:00:44,486
[19]: 00:00:49,375
[20]: 00:00:52,302
[21]: 00:01:00,957
[22]: 00:01:01,757
[23]: 00:01:04,076
[24]: 00:01:05,614
[25]: 00:01:07,819
[26]: 00:01:10,247
[27]: 00:01:13,411
[28]: 00:02:20,377
[29]: 00:02:40,915

<?nuromd version="1.0" encoding="utf-8" ?>
<head>
    <meta name="generator" content="Nuro.video"/>
    <link rel="contents" type="bunny" href="https://cdn.nuro.video/b0992ae3-1871-46d6-b8f2-d01060331c88" /> 
    <link rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/" title="License Information" />
</head>

<del> [1]
Les RÃ©veils de la Nuit - Module 2 [2]
---
</del> [3]

### Sortir de la souffrance mentale et de la dÃ©pendance [4]

- Sandra Manent, coach de vie saine et consciente auprÃ¨s des femmes actives entrepreneurs ou en reconversion [5]
- qui veulent se reconnecter Ã  leur potentiel en Ã©nergies vitalitÃ© sans se sacrifier [6]
- Je vais partager avec vous la raison majeure de notre mal Ãªtre intÃ©rieur [7]
- et comment sortir de la souffrance mentale et de la dÃ©pendance [8]

### Comment sortir de la souffrance mentale et de la dÃ©pendance [9]

- Imaginez que : [10]
- vous puissiez libÃ©rer facilement toutes vos angoisses, vos peurs, vos phobies, votre jalousie, vos colÃ¨res, votre tristesse [11]
- vous vous dÃ©barrassez complÃ¨tement de toutes les choses qui vous empÃªchent de passer votre journÃ©e dans le calme et la joie [12]
- vous n'avez plus besoin de craindre cette situation Ã  venir ou ce rendez vous que vous avez Ã  faire et qui vous fait Ã  rÃ©agir Ã  l'avance [13]
- le manque et l'absence ne soient plus qu'une simple illusion [14]

### Comment sortir de la souffrance mentale et de la dÃ©pendance [15]

- Dans cette vidÃ©o, je vous parle de notre forme pensÃ©e [16]
- Comment elle nourrit et participe Ã  crÃ©er votre souffrance et dÃ©pendance aux choses et aux Ãªtres [17]
- Comment s'en sortir ? [18]

### Qu'est-ce qu'une forme pensÃ©e ? [19]


<!-- End of the project. Nothing is exported beyond this point -->
[1]: 00:00:00,000
[2]: 00:00:00,000
[3]: 00:00:06,585
[4]: 00:00:06,585
[5]: 00:00:15,296
[6]: 00:00:20,598
[7]: 00:00:26,480
[8]: 00:00:30,404
[9]: 00:00:34,353
[10]: 00:00:36,296
[11]: 00:00:37,657
[12]: 00:00:43,454
[13]: 00:00:50,240
[14]: 00:00:58,080
[15]: 00:00:59,889
[16]: 00:01:07,711
[17]: 00:01:09,603
[18]: 00:01:14,774
[19]: 00:01:17,465

<?nuromd version="1.0" encoding="utf-8" ?>
<head>
    <meta name="generator" content="Nuro.video"/>
    <link rel="contents" href="https://cdn.nuro.video/ac0576f1-d246-4f6f-a958-12412cfb1a42/" /> 
    <link rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/" title="License Information" />
</head>

Sandra Manent
===

Comment sortir de la souffrance mentale et de la dÃ©pendance
---

### Comment sortir de la souffrance mentale et de la dÃ©pendance ```PRESENTER-ONLY``` [1]

<del> [2]
</del> [3]

### Qui suis-je ? [4]

- Sandra Manent, coach de vie saine et consciente auprÃ¨s des femmes actives entrepreneurs ou en reconversion... [5]
  - qui veulent se reconnecter Ã  leur potentiel en Ã©nergies vitalitÃ© sans se sacrifier [6]
- Je vais partager avec vous la raison majeure de notre mal Ãªtre intÃ©rieur [7]
- et comment sortir de la souffrance mentale et de la dÃ©pendance [8]

### Comment sortir de la souffrance mentale et de la dÃ©pendance [9]

- Imaginez que : [10]
  - vous puissiez libÃ©rer facilement toutes vos angoisses, vos peurs, vos phobies, votre jalousie, vos colÃ¨res, votre tristesse [11]
  - vous vous dÃ©barrassez complÃ¨tement de toutes les choses qui vous empÃªchent de passer votre journÃ©e dans le calme et la joie [12]
  - vous n'avez plus besoin de craindre cette situation Ã  venir ou ce rendez vous que vous avez Ã  faire et qui vous fait Ã  rÃ©agir Ã  l'avance [13]
  - le manque et l'absence ne soient plus qu'une simple illusion [14]

### Comment sortir de la souffrance mentale et de la dÃ©pendance [15]

- Dans cette vidÃ©o, je vous parle de notre forme pensÃ©e... [16]
  - Comment elle nourrit et participe Ã  crÃ©er votre souffrance et dÃ©pendance aux choses et aux Ãªtres [17]
  - Comment s'en sortir ? [18]

### Qu'est-ce qu'une forme pensÃ©e ? [19]

<del> [20]
</del> [21]

<!-- End of the project. Nothing is exported beyond this point -->
[1]: 00:00:00,000
[2]: 00:00:00,000
[3]: 00:00:08,500
[4]: 00:00:11,543
[5]: 00:00:14,716
[6]: 00:00:17,716
[7]: 00:00:24,760
[8]: 00:00:28,148
[9]: 00:00:32,671
[10]: 00:00:33,816
[11]: 00:00:33,816
[12]: 00:00:42,828
[13]: 00:00:48,755
[14]: 00:00:56,231
[15]: 00:01:04,383
[16]: 00:01:05,383
[17]: 00:01:06,383
[18]: 00:01:14,693
[19]: 00:01:17,693
[20]: 00:01:20,693
[21]: 00:06:05,693