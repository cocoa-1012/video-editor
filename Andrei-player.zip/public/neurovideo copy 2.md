<?nuromd version="1.0" encoding="utf-8" ?>
<head>
    <meta name="generator" content="Nuro.video"/>
	<meta name="author" content="Andrei Slusari, https://example.org, https://example.org, https://example.org, https://example.org"/>
	 <meta name="description" content="This is the description of the video projectThis is the description of the video projectThis is the description of the video projectThis is the description of the video projectThis is the description of the video projectThis is the description of the video projectThis is the description of the video project."/>
    <link rel='contents' href="./fc4caf9b-05df-47a0-8623-e608f80ffef9" /> 
    <link rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/" title="License Information" />
	<link rel="icon" href="imgpsh_fullsize_anim.png" /> 
</head>

<del> [1]
Les RÃ©veils de la Nuit - Module 2 [2]
---
</del> [3]

### Comment sortir de la souffrance mentale et de la dÃ©pendance `TEXT-ONLY` [4]
### Comment sortir de la souffrance mentale `PRESENTER+TEXT` [5]

- This is a list test item [and it includes a clickable link](https://example.org) This is a list item This is a URL presented [and it incl udes a clickable link](https://example.org)   This is a list test item [and it includes a clickable link](https://example.org) This is a list item This is a URL presented [and it incl udes a clickable link](https://example.org)  [6]
#### This is sub title. [7]
- ![image legend text](https://dummyimages.github.io/2.jpg) [8]

### Comment sortir de la souffrance mentale et de la dÃ©pendance `PRESENTER-ONLY` [9]


- Imaginez que : [10]
- vous puissiez libÃ©rer facilement toutes vos angoisses, vos peurs, vos phobies, votre jalousie, vos colÃ¨res, votre tristesse [11]
- vous vous dÃ©barrassez complÃ¨tement de toutes les choses qui vous empÃªchent de passer votre journÃ©e dans le calme et la joie [12]
- vous n'avez plus besoin de craindre cette situation Ã  venir ou ce rendez vous que vous avez Ã  faire et qui vous fait Ã  rÃ©agir Ã  l'avance [13]
- le manque et l'absence ne soient plus qu'une simple illusion [14]

### Comment sortir de la souffrance mentale et de la dÃ©pendance `PRESENTER-RIGHT+TEXT-LEFT` [15]


- Dans cette vidÃ©o, je vous parle de notre forme pensÃ©e [16]
- Comment elle nourrit et participe Ã  crÃ©er votre souffrance et dÃ©pendance aux choses et aux Ãªtres [17]
- Comment s'en sortir ? [18]

### Qu'est-ce qu'une forme pensÃ©e ? `PRESENTER-RIGHT+TEXT-LEFT` [19]


<!-- End of the project. Nothing is exported beyond this point -->
[1]: 00:00:00,000
[2]: 00:00:00,000
[3]: 00:00:06,585
[4]: 00:00:06,585
[5]: 00:00:07,885
[6]: 00:00:10,598
[7]: 00:00:15,480
[8]: 00:00:17,404
[9]: 00:00:21,353
[10]: 00:00:36,296
[11]: 00:00:37,657
[12]: 00:00:43,454
[13]: 00:00:50,240
[14]: 00:00:58,080
[15]: 00:00:59,889
[16]: 00:01:07,711
[17]: 00:01:09,603
[18]: 00:01:14,774
[19]: 00:01:17,465