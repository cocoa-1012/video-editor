<?nuromd version="1.0" encoding="utf-8" ?>
<head>
    <meta name="generator" content="Nuro.video"/>
	<meta name="author" content="Andrei Slusari, https://example.org, https://example.org, https://example.org, https://example.org"/>
	 <meta name="description" content="This is the description of the video projectThis is the description of the video projectThis is the description of the video projectThis is the description of the video projectThis is the description of the video projectThis is the description of the video projectThis is the description of the video project."/>
    <link rel='contents' type='bunny' href="./fc4caf9b-05df-47a0-8623-e608f80ffef9" /> 
    <link rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/" title="License Information" />
	<link rel="icon" href="./imgpsh_fullsize_anim.png" /> 
</head>

Formation E-Commerce gratuite 3/4 [1]
===

Formation E-Commerce gratuite 3/4 [999]
---

### Bienvenue ```PRESENTER-ONLY``` [1000]

### Ce qui a Ã©tÃ© vu dans les 2 derniÃ¨res vidÃ©os : [2]

- Quels types de produits vendre [3]
- Comment trouver des niches qui cartonnent [4]
- Comment crÃ©er un site professionnel, qui vend [5]
- Le lien est dans la description ci-dessous [500]
- Et aujourd'hui : [501]
	- l'acquisition de trafic... [502]
	- Comment trouver des clients sur tes boutiques [503]

### A la fin de cette formation complÃ¨te de 4 vidÃ©os, tu sauras : [6]

- Toutes les mise Ã  jour dans le e-commerce cette annÃ©e [7]
- CrÃ©er une boutique professionnelle [8]
- Attirer du traffic et des clients [9]
- Quels produits vendre [10]
- Les niches les plus rentables [11]
- Le budget nÃ©cessaire pour commencer [12]
- sdfsdf sdf [13]

### 2 coachings Ã  gagner (valeur 500 â‚¬) [14]

- Pour participer et tenter de gagner : [15]
- Abonne-toi [16]
- Like la vidÃ©o [17]
- Commente : "Meilleure formation ecommerce" [18]

### Dans cette vidÃ©o nous parlerons : [19]

- De la publicitÃ© Google (le SEA) [20]
- Comment attirer du trafic en rÃ©fÃ©rencement natuel (le SEO) [21]
- De Facebook et Instagram Ads [22]
- Des influenceurs [23]
- Et des autres opportunitÃ©s de pub : TikTok, Pinterest... [24]
- Et je donnerai mes meilleurs conseils pour attirer du traffic ! [25]

### Qui suis-je ? [26]

- Enzo HONORÃ‰ [27]
- Entrepreneur sur le web depuis 2016 [28]
- Plus de 7M dâ€™euros gÃ©nÃ©rÃ©s jusquâ€™Ã  ce jour [29]
- Des centaines de personnes accompagnÃ©es dans leur transformation de vie grÃ¢ce au business en ligne [30]

### Le guide ```PRESENTER-ONLY``` [31]

### Lâ€™importance de la gÃ©nÃ©ration de trafic : [32]

- Câ€™est essentiel et le PLUS IMPORTANT ! [33]
- L'acquisition doit Ãªtre votre premiÃ¨re prÃ©occupation [34]
- ... avant mÃªme de penser Ã  dÃ©penser des milliers dâ€™euros dans la crÃ©ation dâ€™un site [35]
- Tous mes sites sont optimisÃ©s pour la gÃ©nÃ©ration de trafic [36]

### La clÃ© numÃ©ro 1 ```PRESENTER-ONLY``` [37]

### Les avantages de Google par rapport Ã  Facebook : [38]

- Le but est d'avoir un business Ã  long terme : [3800]
	- Moins de fluctuations [39]
	- CapacitÃ© de revente plus importante [40]
	- Meilleure valorisation de notre business [41]
	- Ã‡a rassure les futurs investisseurs / racheteurs de notre site [42]

### Les bases du SEA : [43]

- Mettre un budget pour gÃ©nÃ©rer dÃ¨s le dÃ©part des revenus (Ã  contrario du SEO) [44]
- Baisser le budget pub sur google une fois que le SEO est optimisÃ© [45]
- DÃ¨s la premiÃ¨re semaine, une campagne Google Shopping peut Ãªtre rentable [46]

### Screenshot : Google Shopping ```PRESENTER-ONLY``` [47]

### En parallÃ¨le de Google Shopping : [48]
- On va lancer une campagne de branding (au nom de votre site) [49]
- Ã©galement des campagnes en "search" [50]

### Exemple d'annonce textuelle ```PRESENTER-ONLY``` [5000]

### Quels produits choisir ? [5001]

- On se positionne sur les produits best-sellers ou Ã  forte demande [51]

### Optimisation Ã  faire par la suite : [52]

- Enlever les mots-clÃ©s qui ne sont pas pertinents [53]
- Le tout doit Ãªtre rentable [54]
- Il faut donc faire attention au ROAS, continuer d'optimiser : [55]
- On vise 2,8 de retour sur investissement publicitaire [550]

### Ceci a changÃ© la donne pour moi ```PRESENTER-ONLY``` [551]

### Le SEO (rÃ©fÃ©rencement naturel) [56]

- C'est votre capacitÃ© Ã  positionner votre page sur google [57]
- L'avantage c'est que c'est "gratuit"... [58]
- ...Il y a cependant des investissements Ã  faire derriÃ¨re (en temps et en argent) [59]
- Aujourd'hui entre 7% et 10% de nos ventes viennent du rÃ©fÃ©rencement naturel (plus de marge) [60]
- Le SEO est la meilleure solution sur le long terme [61]
- Avec le SEO vous pouvez vraiment appliquer la loi du 80/20 [62]

### Les avantages de Google [63]
- Il n'y pas de grosse mise Ã  jour aussi souvent que sur Facebook [64]
- ComparÃ© aux autres plateformes Ã©mergentes...[65]
	- Google est davantage en mode "tortue" [66]

### L'importance de la structure de page en SEO [67]

- Structurez avec des catÃ©gories et sous-catÃ©gories [68]
- Mettez des balises ALT sur les photos [69]
- Ajoutez vos produits avec la bonne nomenclature, et respectez-la sur tout le site [70]
- Soignez les textes d'explication [71]
- Publiez des articles de blogs pour vous positionner en rÃ©fÃ©rencement naturel (par exemple "le top 10 des meilleurs XYZ...") [72]
	- Google fonctionne "au mÃ©rite" : plus vous fournissez des contenus de qualitÃ©, plus vous Ãªtes rÃ©compensÃ©(e) [720]

### L'achat de liens et de notoriÃ©tÃ© [73]

- Plus il y a de gens qui parlent de vous, plus Google vous mettra en avant [74]
- On va donc acheter des liens de faÃ§on sponsorisÃ©e [75]
- BudgÃ©tez 4 Ã  6 mois pour "craquer le code" et avoir des ventes quotidiennes en trafic organique [750]

### La publicitÃ© sur Facebook [76]

- La politique de Facebook s'est endurcie [77]
- Il y a plus de compÃ©tition [78]
- Les annonceurs sont trÃ¨s douÃ©s [79]

### Notre technique pour la pub sur Facebook [80]

- Faire du testing : dÃ©terminer les produits gagnants sur Google [81]
- On reprend les 3 meilleurs et on les teste sur Facebook [82]
- Faire du testing avec les produits tendance (sur Tiktok, Instagram, YouTube) [83]
- La premiÃ¨re chose Ã  regarder est : [830]
	- Est-ce que Ã§a gÃ©nÃ¨re de l'engagement, des partages, des likes ? [84]
	- Est-ce que Ã§a gÃ©nÃ¨re du clic, des visiteurs et de la conversion ? [85]

### Comparaison ```PRESENTER-ONLY``` [850]

### Les "Updates" : que faut-il savoir AUJOURD'HUI ? [86]

- Les prix ont augmentÃ© et la concurrence aussi [87]
- Les blocages de comptes sont trÃ¨s frÃ©quents dÃ©sormais [88]
- Il vous faudra soigner vos visuels et contenus crÃ©atifs [89]
- Ce n'est plus aussi facile de faire des placements avec les influenceurs [90]

### Les influenceurs ```PRESENTER-ONLY``` [900]

### Cibler les influenceurs ? [901]

- Je vous conseille de prioriser les influenceurs de niche (plus intÃ¨gres et professionnels) [91]

### Mes retours sur les autres sources de trafic : [92]

- Pinterest : pas de gros profits (mais intÃ©ressant pour certaines niches) [93]
- Tik Tok : a du potentiel (influenceur, contenu, pub, etc...) [94]

### RÃ©sumÃ© (le 80/20 de la publicitÃ©) : [95]

- Devenez un expert sur UNE source de trafic [96]
- Puis ensuite diversifiez les sources [97]
- Faites de la publicitÃ©... [98]
- Et basculez sur le SEO [99]
- Je rÃ©partis mon trafic entre ces sources en 60/20/10/10 [990]
  - Le processus est d'investir au dÃ©but en pub, puis d'investir davantage sur le SEO pour qu'il passe de 10% Ã  60% [991]

### Dernier rÃ©cap ```PRESENTER-ONLY``` [992]

### Dans la prochaine et derniÃ¨re vidÃ©o : [100]

- Quel est le budget nÃ©cessaire pour dÃ©marrer [101]
- Les 5 erreurs Ã  Ã©viter pour commencer [102]
- Mes tips pour vous aider Ã  dÃ©marrer [103]
- Et vous serez enfin prÃªt(e) Ã  lancer votre business e-commerce ! [104]

### Ce que vous devez faire maintenant [200]

- TÃ©lÃ©chargez les ressources dont le lien est dans la description ! [201]
- Rejoignez La Tribu (toutes les infos sont aussi ci-dessous) [202]
- Votre chance de gagner le coaching d'une valeur de 500 â‚¬ : Tapez "meilleure formation e-commerce" dans les commentaires ! [203]

<!-- End of the project. Nothing is exported beyond this point -->
[1]: 00:00:00,000
[999]: 00:00:00,000
[1000]: 00:00:00,000
[2]: 00:00:11,832
[3]: 00:00:13,832
[4]: 00:00:17,832
[5]: 00:00:21,764
[500]: 00:00:26,764
[501]: 00:00:28,764
[502]: 00:00:30,764
[503]: 00:00:32,764
[6]: 00:00:34,208
[7]: 00:00:38,369
[8]: 00:00:41,301
[9]: 00:00:43,421
[10]: 00:00:46,248
[11]: 00:00:48,807
[12]: 00:00:50,047
[13]: 00:00:52,020
[14]: 00:01:02,815
[15]: 00:01:04,726
[16]: 00:01:10,039
[17]: 00:01:12,211
[18]: 00:01:13,860
[19]: 00:01:18,912
[20]: 00:01:20,744
[21]: 00:01:24,303
[22]: 00:01:32,286
[23]: 00:01:40,426
[24]: 00:01:44,614
[25]: 00:01:50,267
[26]: 00:02:00,736
[27]: 00:02:01,705
[28]: 00:02:02,569
[29]: 00:02:04,819
[30]: 00:02:09,635
[31]: 00:02:28,277
[32]: 00:02:52,900
[33]: 00:02:54,706
[34]: 00:03:21,769
[35]: 00:03:23,287
[36]: 00:03:43,754
[37]: 00:04:10,528
[38]: 00:06:13,805
[3800]: 00:06:41,805
[39]: 00:06:56,651
[40]: 00:06:59,242
[41]: 00:07:01,257
[42]: 00:07:17,929
[43]: 00:07:27,901
[44]: 00:08:07,973
[45]: 00:08:17,709
[46]: 00:08:40,035
[47]: 00:09:08,638
[48]: 00:11:08,306
[49]: 00:11:10,374
[50]: 00:11:19,639
[5000]: 00:11:24,639
[5001]: 00:11:34,639
[51]: 00:11:36,322
[52]: 00:12:23,057
[53]: 00:12:27,061
[54]: 00:12:39,441
[55]: 00:12:56,925
[550]: 00:13:12,925
[551]: 00:13:30,925
[56]: 00:14:42,926
[57]: 00:14:46,486
[58]: 00:15:05,671
[59]: 00:15:17,658
[60]: 00:15:45,866
[61]: 00:16:21,887
[62]: 00:16:42,695
[63]: 00:17:10,988
[64]: 00:17:13,160
[65]: 00:17:16,537
[66]: 00:17:30,880
[67]: 00:17:49,489
[68]: 00:17:52,054
[69]: 00:17:59,749
[70]: 00:18:08,255
[71]: 00:18:38,773
[72]: 00:19:32,821
[720]: 00:20:38,821
[73]: 00:20:43,828
[74]: 00:20:52,492
[75]: 00:21:06,861
[750]: 00:21:40,861
[76]: 00:22:07,269
[77]: 00:22:49,015
[78]: 00:22:54,904
[79]: 00:22:57,966
[80]: 00:23:07,912
[81]: 00:23:09,168
[82]: 00:23:15,136
[83]: 00:24:05,886
[830]: 00:25:01,886
[84]: 00:25:05,216
[85]: 00:25:15,397
[850]: 00:25:50,397
[86]: 00:28:23,037
[87]: 00:28:35,888
[88]: 00:28:55,047
[89]: 00:30:06,526
[90]: 00:30:55,051
[900]: 00:31:25,051
[901]: 00:34:18,051
[91]: 00:34:27,028
[92]: 00:36:32,371
[93]: 00:36:36,507
[94]: 00:37:14,720
[95]: 00:37:55,157
[96]: 00:38:02,538
[97]: 00:38:24,916
[98]: 00:38:31,590
[99]: 00:39:21,948
[990]: 00:40:04,948
[991]: 00:40:22,948
[992]: 00:40:45,948
[100]: 00:42:14,324
[101]: 00:42:19,009
[102]: 00:42:21,705
[103]: 00:42:27,882
[104]: 00:42:32,882
[200]: 00:42:37,882
[201]: 00:42:47,882
[202]: 00:42:57,882
[203]: 00:43:27,882